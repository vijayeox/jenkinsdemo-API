import React_app from "./react-app";

let guiComponent = {
  SampleComponent: React_app
};
export { guiComponent };
