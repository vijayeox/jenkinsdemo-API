Contains form definitions.
